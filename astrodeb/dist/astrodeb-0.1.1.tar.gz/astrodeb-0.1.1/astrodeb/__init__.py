# astrodeb/__init__.py

from .deblur import deblur_image
