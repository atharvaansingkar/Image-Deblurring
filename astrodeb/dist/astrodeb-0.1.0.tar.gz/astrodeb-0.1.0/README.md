# astrodeb

Deblur astronomical images using Richardson–Lucy deconvolution and wavelet denoising.

## Installation

```bash
pip install astrodeb
